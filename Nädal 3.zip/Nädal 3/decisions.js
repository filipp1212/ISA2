var count = 3;
if(count == 4){console.log('4')

}
else{
    console.log('smth else')
}