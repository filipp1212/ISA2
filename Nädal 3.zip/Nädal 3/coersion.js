let a= 6;
let b = '7';
let c = a+b;
console.log(c);