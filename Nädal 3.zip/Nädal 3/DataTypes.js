let x = 7;
console.log(typeof x);

let y = true;
console.log(typeof y);

let z = 'Hello world';
console.log(typeof z);