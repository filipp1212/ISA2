function sayHello(){
    console.log('------------------');
    console.log('Hello');
    console.log('-------------------');
}

sayHello();