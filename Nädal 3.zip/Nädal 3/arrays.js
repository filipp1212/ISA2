let a = [4, 8, 'Ben'];

console.log(a[1]);

a.push(77);
console.log(a);
console.log(a.length);