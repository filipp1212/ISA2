var a = {
    myProperty : {b: 'hi'}
};
console.log(a.myProperty.b);